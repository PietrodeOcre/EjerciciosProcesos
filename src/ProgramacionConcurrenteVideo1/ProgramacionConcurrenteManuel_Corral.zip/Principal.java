package ProgramacionConcurrenteVideo1;



/*
 * Para lanzar hilos se hereda de Thread
 * Los hlos no se tienen que lanzar cuando se lanzan
 * No sabemos el orden de ejecucion de los hilos
 * Los hilos planifican
 */
public class Principal extends Thread{
	
	private int id;
	
	public Principal(int id) {
		this.id = id;
	}
	
	public void run() {
		System.out.println("Soy el hilo: "+id);
	}
	
	/*
	 * El hiloprincipal seria el que ejecuta lo 
	 * que hay en el main
	 * */
	public static void main(String[] args) {
		
		Principal h1 = new Principal(1);
		Principal h2 = new Principal(2);
		Principal h3 = new Principal(3);
		Principal h4 = new Principal(4);
		Principal h5 = new Principal(5);
		Principal h6 = new Principal(6);
		Principal h7 = new Principal(7);
		Principal h8 = new Principal(8);
		
		h1.start();//Se crea un nuevo hilo
		h2.start();
		h3.start();
		h4.start();
		h5.start();
		h6.start();
		h7.start();
		h8.start();
		
		
		System.out.println("Soy el hilo principal!");
		
		

	}
	
	

}
